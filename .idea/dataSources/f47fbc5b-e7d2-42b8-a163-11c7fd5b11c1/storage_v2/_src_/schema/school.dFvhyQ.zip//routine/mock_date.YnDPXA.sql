create
    definer = root@localhost function mock_date() returns int
begin
	declare num int default 1000000;
	declare i int default 0;
	while i <num do
		-- 插入所有数据
		insert into `app_user` (`name`,`email`,`gender`,`age`) 
		values (concat('用户',i),'23232233212@qq.com',floor(RAND()*2),FLOOR(RAND()*100));
		set i = i+1;	
	end while;
	RETURN i;
end;

